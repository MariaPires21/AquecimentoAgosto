﻿using Aquecimento2.Classes;
using System;

class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Rasputia");
        podeVotar();
    }
    static void podeVotar()
    {
        Pessoas novaPessoa = new Pessoas("Rasputia", 17);
        if (novaPessoa.Idade < 16)
        {
            Console.WriteLine("Não pode votar");
        }
        else
            if (novaPessoa.Idade >= 16 && novaPessoa.Idade <= 17)
        {
            Console.WriteLine("Voto opcional");
        }
        else
            if (novaPessoa.Idade >= 18)
        {
            Console.WriteLine("Voto obrigatório");
        }
    }
}
